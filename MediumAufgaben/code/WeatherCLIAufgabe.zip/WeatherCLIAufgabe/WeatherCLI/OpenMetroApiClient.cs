﻿using System.Buffers.Text;
using System.Text.Json;
using WeatherCLI.Dto;

namespace WeatherCLI;

internal class OpenMetroApiClient
{
	private const string _BaseUrl = "https://api.open-meteo.com/v1";

	private readonly HttpClient _client;

	public OpenMetroApiClient()
	{
		_client = new HttpClient();
	}

	public async Task<OpenMetroResponse?> GetTemperature()
	{
		var response = await _client.GetAsync(_BaseUrl + ForecastRequest.GetRequest());
		if (response.IsSuccessStatusCode)
		{
			return JsonSerializer.Deserialize<OpenMetroResponse>(await response.Content.ReadAsStringAsync());
		}
		return null;
	}
}
