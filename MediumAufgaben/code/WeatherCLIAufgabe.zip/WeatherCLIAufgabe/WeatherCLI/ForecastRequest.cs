﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeatherCLI;

internal class ForecastRequest
{
	private const string _Latitude = "49";
	private const string _Longitude = "8.44";
	private const string _PastDays = "7";
	private const string _ForecastDays = "14";

	public static string GetRequest()
	{
		return $"/forecast?latitude={_Latitude}&longitude={_Longitude}&hourly=temperature_2m&past_days={_PastDays}&forecast_days=14";
	}
}
