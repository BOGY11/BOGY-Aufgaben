﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace WeatherCLI.Dto;

public record OpenMetroResponse
{
	[JsonPropertyName("latitude")]
	public double Latitude { get; init; }

	[JsonPropertyName("longitude")]
	public double Longitude { get; init; }

	[JsonPropertyName("generationtime_ms")]
	public double GenerationTimeMs { get; init; }

	[JsonPropertyName("utc_offset_seconds")]
	public int UtcOffsetSeconds { get; init; }

	[JsonPropertyName("timezone")]
	public string Timezone { get; init; } = string.Empty;

	[JsonPropertyName("timezone_abbreviation")]
	public string TimezoneAbbreviation { get; init; } = string.Empty;

	[JsonPropertyName("elevation")]
	public double Elevation { get; init; }

	[JsonPropertyName("hourly_units")]
	public HourlyUnits HourlyUnits { get; init; } = new();

	[JsonPropertyName("hourly")]
	public Hourly Hourly { get; init; } = new();
}

public record HourlyUnits
{
	[JsonPropertyName("time")]
	public string Time { get; init; } = string.Empty;

	[JsonPropertyName("temperature_2m")]
	public string Temperature2m { get; init; } = string.Empty;
}

public record Hourly
{
	[JsonPropertyName("time")]
	public List<string> Time { get; init; } = new();

	[JsonPropertyName("temperature_2m")]
	public List<double> Temperature2m { get; init; } = new();
}

