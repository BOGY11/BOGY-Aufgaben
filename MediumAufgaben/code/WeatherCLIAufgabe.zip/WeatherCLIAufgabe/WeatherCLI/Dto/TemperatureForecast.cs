﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeatherCLI.Dto;

internal class TemperatureForecast
{
	private readonly List<DateTime> _time;
	private readonly List<double> _temperature;

	public List<DateTime> Time { get => _time; }
	public List<double> Temperature { get => _temperature; }

	public Dictionary<DateTime, double> TimeTemperature { get; private init; }

	public TemperatureForecast(OpenMetroResponse response)
	{
		_time = response.Hourly.Time.Select(DateTime.Parse).ToList();
		_temperature = response.Hourly.Temperature2m;
		TimeTemperature = new Dictionary<DateTime, double>();
		for (int i = 0; i < _time.Count; i++) 
		{
			TimeTemperature.Add(_time[i], _temperature[i]);
		}
	}
}
