﻿using Spectre.Console;
using WeatherCLI.Dto;

namespace WeatherCLI;

internal class ForecastTable
{
	private Table _table;
	private readonly TemperatureForecast _forecast;
	private string[] _tableColumns;
	private IEnumerable<DateOnly> _dateOnlyList;

	public ForecastTable(TemperatureForecast forecast)
	{
		_forecast = forecast;
		_table = new Table();
		SetTableHorizontal(0, 7);
	}

	public async Task StartAsync()
	{
		await AnsiConsole.Live(_table).StartAsync(async ctx =>
		{
			var selectionIndexVertical = 0;
			var selectionIndexHorizontal = 7;
			while (selectionIndexVertical != -1)
			{
				ctx.Refresh();
				var currentInput = await Console.GetConsoleInput();
				if (currentInput.Value.Key == ConsoleKey.UpArrow)
				{
					selectionIndexVertical = selectionIndexVertical == 0 ? 0 : selectionIndexVertical - 1;
					SetTableVertical(selectionIndexVertical);
				}

				if (currentInput.Value.Key == ConsoleKey.DownArrow)
				{
					selectionIndexVertical = selectionIndexVertical == 12 ? selectionIndexVertical : selectionIndexVertical + 1;
					SetTableVertical(selectionIndexVertical);
				}

				if (currentInput.Value.Key == ConsoleKey.LeftArrow)
				{
					selectionIndexHorizontal = selectionIndexHorizontal == 0 ? selectionIndexHorizontal : selectionIndexHorizontal - 1;
					SetTableHorizontal(selectionIndexVertical, selectionIndexHorizontal);
					ctx.UpdateTarget(_table);
				}

				if (currentInput.Value.Key == ConsoleKey.RightArrow)
				{
					selectionIndexHorizontal = selectionIndexHorizontal == 14 ? selectionIndexHorizontal : selectionIndexHorizontal + 1;
					SetTableHorizontal(selectionIndexVertical, selectionIndexHorizontal);
					ctx.UpdateTarget(_table);
				}
			}
		});
	}

	private void SetTableVertical(int selectionIndex)
	{
		
	}

	private void SetTableHorizontal(int selectionIndexVertical, int selectionIndexHorizontal)
	{
		_dateOnlyList = _forecast.Time.Select(t => DateOnly.Parse(t.Date.ToString().Split(' ')[0])).Distinct().Take(new Range(selectionIndexHorizontal, selectionIndexHorizontal + 7));
		_tableColumns = _dateOnlyList.Select(d =>
				DateTime.Now.ToString().Contains(d.ToString()) ?
					$"[bold white]{d}[/]" :
					d.ToString()
			)
			.ToArray();
		_table = new Table();
		_table.AddColumn(new TableColumn(
					new Markup(
						"  ╲ Date" +
						"\n ╲ \n" +
						"Time╲  "
						)
				).Centered());
		_table.AddColumns(_tableColumns);

		//====================Hier dein Code einfügen====================




		//===============================================================
	}

	private Markup GetTemperatureMarkup(double temperature)
	{
		return temperature switch
		{
			<= -20 => new Markup($"{temperature:f1} °C", new Style(Color.DarkBlue)),
			> -20 and <= -15 => new Markup($"{temperature:f1} °C", new Style(Color.Blue3)),
			> -15 and <= -10 => new Markup($"{temperature:f1} °C", new Style(Color.Blue)),
			> -10 and <= -5 => new Markup($"{temperature:f1} °C", new Style(Color.DodgerBlue1)),
			> -5 and <= 0 => new Markup($"{temperature:f1} °C", new Style(Color.DeepSkyBlue1)),
			> 0 and <= 5 => new Markup($"{temperature:f1} °C", new Style(Color.Cyan)),
			> 5 and <= 10 => new Markup($"{temperature:f1} °C", new Style(Color.SpringGreen2)),
			> 10 and <= 15 => new Markup($"{temperature:f1} °C", new Style(Color.Green1)),
			> 15 and <= 20 => new Markup($"{temperature:f1} °C", new Style(Color.Chartreuse1)),
			> 20 and <= 25 => new Markup($"{temperature:f1} °C", new Style(Color.Yellow1)),
			> 25 and <= 30 => new Markup($"{temperature:f1} °C", new Style(Color.Gold1)),
			> 30 and <= 35 => new Markup($"{temperature:f1} °C", new Style(Color.Orange1)),
			> 35 and <= 40 => new Markup($"{temperature:f1} °C", new Style(Color.DarkOrange)),
			> 40 and <= 45 => new Markup($"{temperature:f1} °C", new Style(Color.OrangeRed1)),
			> 45 and <= 50 => new Markup($"{temperature:f1} °C", new Style(Color.Red1))
		};
	}
}
