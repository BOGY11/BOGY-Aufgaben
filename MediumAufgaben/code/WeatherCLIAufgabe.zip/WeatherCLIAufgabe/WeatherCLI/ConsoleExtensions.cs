﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeatherCLI;

internal static class ConsoleExtensions
{
	extension(Console)
	{
		public static async Task<ConsoleKeyInfo?> GetConsoleInput(CancellationToken stoppingToken = default)
		{
			while (!stoppingToken.IsCancellationRequested)
			{
				if (Console.KeyAvailable)
				{
					return Console.ReadKey(intercept: false);
				}
				await Task.Delay(100);
			}
			return null;
		}
	}
}
