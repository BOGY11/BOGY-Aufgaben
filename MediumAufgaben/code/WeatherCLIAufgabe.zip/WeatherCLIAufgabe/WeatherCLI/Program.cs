﻿using WeatherCLI;
using WeatherCLI.Dto;

Console.OutputEncoding = System.Text.Encoding.UTF8;

var openMetroClient = new OpenMetroApiClient();

var response = await openMetroClient.GetTemperature();
var forecast = new TemperatureForecast(response);
var forecastTable = new ForecastTable(forecast);

await forecastTable.StartAsync();